const config = {
  port: process.env.PORT || 9000, // Port bisa disesuaikan dari environment variable atau default ke 9000
};

export default config;
