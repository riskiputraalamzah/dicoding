# Proyek Klasifikasi Gambar: Animals-10

Proyek ini dibuat untuk submission kelas "Belajar Pengembangan Machine Learning" di Dicoding.

## Struktur Direktori
submission
├───tfjs_model
| ├───group1-shard1of1.bin
| └───model.json
├───tflite
| ├───model.tflite
| └───label.txt
├───saved_model
| ├───saved_model.pb
| └───variables
├───notebook.ipynb
├───README.md
└───requirements.txt